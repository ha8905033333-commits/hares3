package com.hares.monitor

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PinActivity : AppCompatActivity() {
    private lateinit var secure: SecurePrefs
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pin)
        secure = SecurePrefs(this)
        val input = findViewById<EditText>(R.id.pinInput)
        val title = findViewById<TextView>(R.id.pinTitle)
        val button = findViewById<Button>(R.id.pinButton)
        val error = findViewById<TextView>(R.id.pinError)

        if (secure.hasPin()) {
            title.text = "أدخل رمز PIN"
            button.text = "دخول"
        } else {
            title.text = "أنشئ رمز PIN من 6 أرقام"
            button.text = "إنشاء"
        }

        button.setOnClickListener {
            val pin = input.text.toString()
            if (pin.length != 6) {
                error.text = "يجب أن يكون الرمز 6 أرقام"
                return@setOnClickListener
            }
            if (!secure.hasPin()) {
                secure.setPin(pin)
                openMain()
            } else if (secure.verify(pin)) {
                openMain()
            } else {
                error.text = "رمز PIN غير صحيح"
                input.text.clear()
            }
        }
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
