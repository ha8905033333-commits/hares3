package com.hares.monitor

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.graphics.RectF

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var status: TextView
    private lateinit var startStop: Button
    private var front = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startMonitoringIfReady() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                MonitoringService.ACTION_BOXES -> {
                    val a = intent.getFloatArrayExtra(MonitoringService.EXTRA_BOXES) ?: floatArrayOf()
                    val boxes = a.toList().chunked(4).filter { it.size == 4 }.map {
                        RectF(it[0], it[1], it[2], it[3])
                    }
                    overlay.setBoxes(boxes)
                }
                MonitoringService.ACTION_EVENT -> flashScreen()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        overlay = findViewById(R.id.overlay)
        status = findViewById(R.id.status)
        startStop = findViewById(R.id.startStop)

        startPreview()
        startStop.setOnClickListener {
            if (MonitoringService.running.get()) stopMonitoring() else requestPermissionsAndStart()
        }
        findViewById<Button>(R.id.cameraSwitch).setOnClickListener {
            front = !front
            startPreview()
        }
        findViewById<Button>(R.id.galleryButton).setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val filter = IntentFilter().apply {
            addAction(MonitoringService.ACTION_BOXES)
            addAction(MonitoringService.ACTION_EVENT)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startMonitoringIfReady() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val i = Intent(this, MonitoringService::class.java)
        ContextCompat.startForegroundService(this, i)
        status.text = "🟢 المراقبة نشطة"
        startStop.text = "⏹ إيقاف المراقبة"
    }

    private fun stopMonitoring() {
        stopService(Intent(this, MonitoringService::class.java))
        status.text = "🔴 متوقفة"
        startStop.text = "▶ بدء المراقبة"
        overlay.setBoxes(emptyList())
    }

    private fun startPreview() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also {
                it.setSurfaceProvider(preview.surfaceProvider)
            }
            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, previewUseCase)
            } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    private fun flashScreen() {
        if (!SettingsStore(this).screenFlash) return
        val original = window.attributes.screenBrightness
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val old = window.decorView.background
        window.decorView.setBackgroundColor(0xFFFFFFFF.toInt())
        window.decorView.postDelayed({
            window.decorView.setBackgroundColor(0x00000000)
            window.attributes = window.attributes.apply { screenBrightness = original }
            if (old != null) window.decorView.background = old
        }, 300)
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}
