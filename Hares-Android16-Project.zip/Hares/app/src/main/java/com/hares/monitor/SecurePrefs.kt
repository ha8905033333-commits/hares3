package com.hares.monitor

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

class SecurePrefs(context: Context) {
    private val prefs = context.getSharedPreferences("secure", Context.MODE_PRIVATE)

    fun hasPin() = prefs.contains("pin_hash") && prefs.contains("pin_salt")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString("pin_salt", salt.hex()).putString("pin_hash", hash(pin, salt)).apply()
    }

    fun verify(pin: String): Boolean {
        val salt = prefs.getString("pin_salt", null)?.hexToBytes() ?: return false
        val expected = prefs.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
    }

    private fun hash(pin: String, salt: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        repeat(120_000) { md.update(salt); md.update(pin.toByteArray(Charsets.UTF_8)) }
        return md.digest().hex()
    }

    private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
