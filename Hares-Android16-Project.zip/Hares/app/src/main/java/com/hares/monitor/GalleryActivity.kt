package com.hares.monitor

import android.os.Bundle
import android.os.Environment
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class GalleryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        val grid = findViewById<GridView>(R.id.grid)
        val dir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Hares")
        val images = dir.listFiles()?.filter { it.extension.lowercase() in setOf("jpg","jpeg","png") }?.sortedDescending() ?: emptyList()
        val adapter = object : BaseAdapter() {
            override fun getCount() = images.size
            override fun getItem(position: Int) = images[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val iv = (convertView as? ImageView) ?: ImageView(this@GalleryActivity).apply {
                    layoutParams = AbsListView.LayoutParams(260, 260)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }
                iv.setImageURI(android.net.Uri.fromFile(images[position]))
                iv.setOnLongClickListener {
                    images[position].delete()
                    recreate()
                    true
                }
                return iv
            }
        }
        grid.adapter = adapter
    }
}
