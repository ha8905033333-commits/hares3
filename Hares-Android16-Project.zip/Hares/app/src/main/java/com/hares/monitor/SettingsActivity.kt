package com.hares.monitor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var s: SettingsStore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        s = SettingsStore(this)

        val sensitivity = findViewById<SeekBar>(R.id.sensitivity)
        val minArea = findViewById<SeekBar>(R.id.minArea)
        val cooldown = findViewById<SeekBar>(R.id.cooldown)
        val performance = findViewById<Spinner>(R.id.performance)

        sensitivity.progress = s.sensitivity
        minArea.progress = s.minArea
        cooldown.progress = s.cooldownSec
        performance.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("🔋 توفير البطارية", "⚖️ متوازن", "🚀 عالي الأداء"))
        performance.setSelection(s.performance)

        fun updateLabels() {
            findViewById<TextView>(R.id.sensitivityLabel).text = "الحساسية: ${sensitivity.progress}"
            findViewById<TextView>(R.id.minAreaLabel).text = "الحد الأدنى للحركة: ${minArea.progress}"
            findViewById<TextView>(R.id.cooldownLabel).text = "فترة التهدئة: ${cooldown.progress} ثوانٍ"
        }
        updateLabels()
        sensitivity.setOnSeekBarChangeListener(simple { s.sensitivity = it; updateLabels() })
        minArea.setOnSeekBarChangeListener(simple { s.minArea = it; updateLabels() })
        cooldown.setOnSeekBarChangeListener(simple { s.cooldownSec = it; updateLabels() })
        performance.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { s.performance = pos }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }

        bind(R.id.soundEnabled) { s.sound = it }
        bind(R.id.screenFlash) { s.screenFlash = it }
        bind(R.id.notificationEnabled) { s.notification = it }
        bind(R.id.saveImages) { s.saveImages = it }
        bind(R.id.dimScreen) { s.dimScreen = it }
        bind(R.id.chargeOnly) { s.chargeOnly = it }
        findViewById<SeekBar>(R.id.volume).progress = s.volume
        findViewById<SeekBar>(R.id.volume).setOnSeekBarChangeListener(simple { s.volume = it })

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "تحسين البطارية متوقف لهذا التطبيق", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.changePin).setOnClickListener {
            startActivity(Intent(this, PinActivity::class.java).putExtra("change", true))
        }
    }

    private fun bind(id: Int, setter: (Boolean) -> Unit) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = when(id) {
            R.id.soundEnabled -> s.sound
            R.id.screenFlash -> s.screenFlash
            R.id.notificationEnabled -> s.notification
            R.id.saveImages -> s.saveImages
            R.id.dimScreen -> s.dimScreen
            else -> s.chargeOnly
        }
        sw.setOnCheckedChangeListener { _, checked -> setter(checked) }
    }

    private fun simple(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { block(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }
}
