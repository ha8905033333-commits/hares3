package com.hares.monitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class MonitoringService : LifecycleService() {
    companion object {
        const val ACTION_BOXES = "com.hares.monitor.BOXES"
        const val EXTRA_BOXES = "boxes"
        const val ACTION_EVENT = "com.hares.monitor.EVENT"
        const val CHANNEL = "monitoring"
        var running = AtomicBoolean(false)
    }

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var detector: MotionDetector
    private var lastAlert = 0L
    private var cameraProvider: ProcessCameraProvider? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1001, notification("المراقبة نشطة"))
        val s = SettingsStore(this)
        detector = MotionDetector(s.sensitivity, s.minArea)
        running.set(true)
        bindCamera()
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setImageQueueDepth(1)
                .build()
            analysis.setAnalyzer(executor) { image ->
                analyze(image)
            }
            val selector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, selector, analysis)
            } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(image: ImageProxy) {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val w = image.width
        val h = image.height
        val boxes = detector.detect(bytes, w, h).map { it.rect }

        val packed = boxes.flatMap { listOf(it.left, it.top, it.right, it.bottom) }.toFloatArray()
        sendBroadcast(Intent(ACTION_BOXES).setPackage(packageName).putExtra(EXTRA_BOXES, packed))

        if (boxes.isNotEmpty()) {
            val now = System.currentTimeMillis()
            val cooldown = SettingsStore(this).cooldownSec * 1000L
            if (now - lastAlert >= cooldown) {
                lastAlert = now
                sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName))
                if (SettingsStore(this).notification) {
                    val n = notification("تم اكتشاف حركة")
                    (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1002, n)
                }
            }
        }
        image.close()
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_hare)
            .setContentTitle("🛡️ حارس")
            .setContentText(text)
            .setOngoing(text == "المراقبة نشطة")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(CHANNEL, "مراقبة حارس", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    override fun onDestroy() {
        running.set(false)
        cameraProvider?.unbindAll()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)
}
