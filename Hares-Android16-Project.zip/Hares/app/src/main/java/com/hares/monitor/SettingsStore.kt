package com.hares.monitor

import android.content.Context

class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var sensitivity: Int get() = p.getInt("sensitivity", 60) set(v) { p.edit().putInt("sensitivity", v).apply() }
    var minArea: Int get() = p.getInt("minArea", 80) set(v) { p.edit().putInt("minArea", v).apply() }
    var cooldownSec: Int get() = p.getInt("cooldown", 4) set(v) { p.edit().putInt("cooldown", v).apply() }
    var performance: Int get() = p.getInt("performance", 1) set(v) { p.edit().putInt("performance", v).apply() }
    var sound: Boolean get() = p.getBoolean("sound", true) set(v) { p.edit().putBoolean("sound", v).apply() }
    var screenFlash: Boolean get() = p.getBoolean("screenFlash", true) set(v) { p.edit().putBoolean("screenFlash", v).apply() }
    var notification: Boolean get() = p.getBoolean("notification", true) set(v) { p.edit().putBoolean("notification", v).apply() }
    var saveImages: Boolean get() = p.getBoolean("saveImages", true) set(v) { p.edit().putBoolean("saveImages", v).apply() }
    var dimScreen: Boolean get() = p.getBoolean("dimScreen", false) set(v) { p.edit().putBoolean("dimScreen", v).apply() }
    var chargeOnly: Boolean get() = p.getBoolean("chargeOnly", false) set(v) { p.edit().putBoolean("chargeOnly", v).apply() }
    var volume: Int get() = p.getInt("volume", 80) set(v) { p.edit().putInt("volume", v).apply() }
}
