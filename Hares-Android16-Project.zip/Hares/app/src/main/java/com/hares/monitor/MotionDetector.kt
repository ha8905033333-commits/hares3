package com.hares.monitor

import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class MotionBox(val rect: RectF, val score: Int)

class MotionDetector(
    private val sensitivity: Int,
    private val minArea: Int
) {
    private var previous: ByteArray? = null
    private var previousW = 0
    private var previousH = 0

    fun detect(gray: ByteArray, width: Int, height: Int): List<MotionBox> {
        val old = previous
        if (old == null || previousW != width || previousH != height) {
            previous = gray.clone()
            previousW = width; previousH = height
            return emptyList()
        }

        // Downsampled grayscale diff. Lower threshold = more sensitive.
        val threshold = max(4, 40 - (sensitivity * 34 / 100))
        val step = 4
        val gw = width / step
        val gh = height / step
        val active = BooleanArray(gw * gh)

        for (y in 0 until gh) {
            val sy = y * step
            for (x in 0 until gw) {
                val sx = x * step
                val idx = sy * width + sx
                val d = abs((gray[idx].toInt() and 255) - (old[idx].toInt() and 255))
                active[y * gw + x] = d >= threshold
            }
        }

        val visited = BooleanArray(active.size)
        val result = ArrayList<MotionBox>()
        val qx = IntArray(active.size)
        val qy = IntArray(active.size)

        for (sy in 0 until gh) for (sx in 0 until gw) {
            val start = sy * gw + sx
            if (!active[start] || visited[start]) continue
            var head = 0; var tail = 0
            qx[tail] = sx; qy[tail] = sy; tail++
            visited[start] = true
            var minX = sx; var maxX = sx; var minY = sy; var maxY = sy; var count = 0

            while (head < tail) {
                val x = qx[head]; val y = qy[head]; head++; count++
                minX = min(minX, x); maxX = max(maxX, x)
                minY = min(minY, y); maxY = max(maxY, y)
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx; val ny = y + dy
                    if (nx !in 0 until gw || ny !in 0 until gh) continue
                    val ni = ny * gw + nx
                    if (active[ni] && !visited[ni]) {
                        visited[ni] = true
                        qx[tail] = nx; qy[tail] = ny; tail++
                    }
                }
            }

            if (count * step * step >= minArea) {
                result += MotionBox(
                    RectF(
                        (minX * step).toFloat(),
                        (minY * step).toFloat(),
                        ((maxX + 1) * step).toFloat(),
                        ((maxY + 1) * step).toFloat()
                    ),
                    count
                )
            }
        }

        previous = gray.clone()
        return mergeNearby(result)
    }

    private fun mergeNearby(input: List<MotionBox>): List<MotionBox> {
        val out = ArrayList<MotionBox>()
        for (b in input.sortedByDescending { it.score }) {
            var merged = false
            for (i in out.indices) {
                val a = out[i].rect
                val expanded = RectF(a.left - 24, a.top - 24, a.right + 24, a.bottom + 24)
                if (expanded.intersects(b.rect.left, b.rect.top, b.rect.right, b.rect.bottom)) {
                    a.union(b.rect)
                    merged = true
                    break
                }
            }
            if (!merged) out += MotionBox(RectF(b.rect), b.score)
        }
        return out.take(12)
    }
}
