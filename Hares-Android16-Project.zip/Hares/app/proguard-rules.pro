# Hares currently ships without code shrinking.
